import { Component } from '@angular/core';
import { Table } from '../interfaces/table'
import { MembreService } from '../services/membre.service';

@Component({
  selector: 'app-reservation',
  templateUrl: './reservation.component.html',
  styleUrls: ['./reservation.component.css']
})
export class ReservationComponent  {
  
  public membres: Array <Table> = new Array <Table>();
  constructor(private membreService: MembreService) { }

  ngOnInit(): void {
    this.membreService.getMembres().subscribe(data =>(this.membres=data));

  }


    getDate(): string {
      const date = new Date();
      if (date.getHours() >= 14) {
        date.setDate(date.getDate() + 2);
      }
      return date.toLocaleDateString('fr-FR', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });
    }
  }
