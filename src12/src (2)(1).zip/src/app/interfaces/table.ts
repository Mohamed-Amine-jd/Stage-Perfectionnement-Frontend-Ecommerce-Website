export interface Table {
  id: string;
  name: string;
  party: number;
  time: string;
  valide:boolean;
  photo:  string;
}
