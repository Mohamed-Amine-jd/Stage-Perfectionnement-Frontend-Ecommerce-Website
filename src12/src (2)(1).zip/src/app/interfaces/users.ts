export interface Users {
    id?:string;
    nom: string;
    prenom:string;
    email: string;
    password: string;
    profile?: string;
    valide?:  string;
}
