export interface Personne {
      id?: number;
      nom?: string;
      prenom?: string;
      photo? :string;

}

