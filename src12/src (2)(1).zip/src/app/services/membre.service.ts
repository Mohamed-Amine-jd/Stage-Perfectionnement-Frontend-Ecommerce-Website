import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Table } from '../interfaces/table';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class MembreService {
  private _apiUrl: string = 'http://localhost:3000/table';
  constructor(private http: HttpClient) {}
  
  getMembres():Observable<Table[]> {
    return this.http.get<Table[]>(this._apiUrl);
  }
}
