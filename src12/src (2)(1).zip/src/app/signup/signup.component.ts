import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  signupForm!: FormGroup;

  constructor(private formBuilder: FormBuilder) {}

  ngOnInit(): void {
    this.signupForm = this.formBuilder.group({
      nom: ['', [
        Validators.required,
        Validators.minLength(5),
        Validators.maxLength(11),
        Validators.pattern(/^[A-Z][a-zA-Z]{4,10}$/)
      ]],
      prenom: ['', [
        Validators.required,
        Validators.minLength(5),
        Validators.maxLength(11),
        Validators.pattern(/^[A-Z][a-zA-Z]{4,10}$/)
      ]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]]
    });
  }

  signUp() {
    if (this.signupForm.valid) {
      const nomValue = this.signupForm.get('nom')?.value;
      const prenomValue = this.signupForm.get('prenom')?.value;

      // Mettre la première lettre en majuscule
      this.signupForm.patchValue({
        nom: nomValue.charAt(0).toUpperCase() + nomValue.slice(1),
        prenom: prenomValue.charAt(0).toUpperCase() + prenomValue.slice(1)
      });

      console.log(this.signupForm.value);
      // Ici, tu peux effectuer des actions pour soumettre les données du formulaire
    } else {
      // Traiter les actions à effectuer si le formulaire n'est pas valide
    }
  }
}
